package com.example.unitconverter;

public interface ComunicaOpciones {
    public void opciones(int presionado);
}
