package com.example.unitconverter;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class Fragmento4 extends Fragment implements View.OnClickListener{

    TextView resultado;
    EditText numero;
    Button botona;
    float num;
    String paso, seleccion, seleccion2;
    Spinner spinner, spinner2;

    public Fragmento4() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_fragmento4, container, false);
        numero = (EditText) v.findViewById(R.id.numero);
        resultado = (TextView) v.findViewById(R.id.numeroImprimir);
        botona = (Button) v.findViewById(R.id.boton2a);
        spinner = (Spinner) v.findViewById(R.id.spinner); //implementacion de spinner
        ArrayAdapter adapter = ArrayAdapter.createFromResource(this.getContext(), R.array.volumen, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(com.google.android.material.R.layout.support_simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                seleccion = parent.getItemAtPosition(position).toString();
                Log.i("Selecciono algo?", seleccion);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinner2 = (Spinner) v.findViewById(R.id.spinner2); //implementacion de spinner2
        spinner2.setAdapter(adapter);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                seleccion2 = parent.getItemAtPosition(position).toString();
                Log.i("Segunda selleccion", seleccion2);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        botona.setOnClickListener(this);

        return v;
    }

    @Override
    public void onClick(View v) {
        num = Integer.parseInt(numero.getText().toString());
        Log.i("Estoy en onClick", seleccion);

        if(seleccion.equals("l"))
        {
            if(seleccion2.equals("ml")) num = num * 1000;
            else if (seleccion2.equals("dl")) num = num * 10;
            else if (seleccion2.equals("l")) num = num ;
            else if (seleccion2.equals("mm^3")) num =  num * 1000000;
            else if (seleccion2.equals("cm^3")) num = (float) (num * 1000);
            else if (seleccion2.equals("dm^3")) num = num ;
            else if (seleccion2.equals("m^3")) num = (float) (num * 0.001);
            else if (seleccion2.equals("in^3")) num = (float) (num * 61.0237);
            else if (seleccion2.equals("ft^3")) num = (float) (num *  0.0353147);
            else if (seleccion2.equals("yd^3")) num = (float) (num *  0.00130795);
            else if (seleccion2.equals("gal")) num = (float) (num *  0.264172);
        }

        paso = String.format("%32.6f",num);
        resultado.setText(paso);

    }
}